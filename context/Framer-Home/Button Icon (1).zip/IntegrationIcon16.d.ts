export interface Integrationicon16Props {
  /**
   * Icon — pass as `z6AwEa6gl` not `icon`.
   */
  z6AwEa6gl?: string;
  /** Additional properties */
  [key: string]: unknown;
}
